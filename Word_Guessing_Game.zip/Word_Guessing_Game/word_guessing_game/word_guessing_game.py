import random
import re

def read_words():
    with open("words.txt", "r") as file:
        try:
            words = file.read().splitlines()
            return words
        except FileNotFoundError:
            print("words.txt does not exis.")
            return []

def display_word(secrete_word, guessed_letters):
    word_to_display = ""

    for letter in secrete_word:
        if letter in guessed_letters:
            word_to_display += letter
        else:
            word_to_display += "_"

    print(word_to_display)

def get_guess(guessed_letters):
    while True:
        guess = input("Enter a letter: ").lower()
        if len(guess) != 1:
            print("Enter only 1 letter.")
        elif not re.search("[a-z]", guess):
            print("Enter only letters from a to z.")
        elif guess in guessed_letters:
            print("You already guessed that letter.")
        else:
            return guess

def is_word_guessed(secrete_word, guessed_letters):
    for letter in secrete_word:
        if letter not in guessed_letters:
            return False
    return True

def main():
    words = read_words()
    if not words:
        print("No words loaded.")
        return
    secrete_word = random.choice(words)
    print(secrete_word)

    attempts = 6
    guessed_letters = []
    while attempts > 0:
        display_word(secrete_word, guessed_letters)

        guess = get_guess(guessed_letters)
        guessed_letters.append(guess)

        if guess in secrete_word:
            print("Good guess.")
            if is_word_guessed(secrete_word, guessed_letters):
                print("Congratulations! You guessed the word.")
                break
        else:
            print("Wrong guess")
            attempts -= 1
            if attempts == 0:
                print(f"Game over! The word was {secrete_word}")

if __name__ == "__main__":
    main()