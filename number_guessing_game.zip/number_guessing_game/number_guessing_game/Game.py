import random

random_number = random.randint(1, 100)

while True:
    try:
        guess_number = int(input("Guess number between 1 and 100: "))
        if guess_number > random_number:
            print("Too high!")
        elif guess_number < random_number:
            print("Too low!")
        elif guess_number == random_number:
            print("Congratulation! You guessed the number.")
            break
    except ValueError:
        print("Please enter valid number!")
